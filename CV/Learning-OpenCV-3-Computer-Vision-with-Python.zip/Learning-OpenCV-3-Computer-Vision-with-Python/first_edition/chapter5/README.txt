Scripts are in the "cameo" folder. Haar cascade files are in the "cameo/cascades" folder.

The managers.py script is unchanged since Chapter 2.

The filters.py script is unchanged since Chapter 3.

The trackers.py and utils.py scripts are unchanged since Chapter 4.

The Haar cascade files are unchanged since Chapter 4.